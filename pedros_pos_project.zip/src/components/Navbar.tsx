import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Boxes, 
  TrendingUp, 
  Barcode, 
  Store, 
  RefreshCw,
  Sparkles,
  PackagePlus,
  ShieldAlert,
  Download,
  HelpCircle,
  X,
  Globe,
  Laptop,
  CheckCircle2,
  FileArchive
} from 'lucide-react';
import { ActiveTab, Currency, Product, SaleRecord } from '../types';
import { formatNumber, formatPrice } from '../utils/formatters';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  products: Product[];
  sales: SaleRecord[];
  onResetSampleData: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  products,
  sales,
  onResetSampleData,
}) => {
  const totalStock = products.reduce((acc, p) => acc + p.stock, 0);
  const totalSold = products.reduce((acc, p) => acc + p.soldCount, 0);
  const totalRevenue = sales.reduce((acc, s) => acc + s.totalAmount, 0);
  const outOfStockCount = products.filter((p) => p.stock <= 0).length;
  const [showExportModal, setShowExportModal] = useState(false);

  return (
    <header className="bg-stone-950 border-b border-stone-800 shrink-0 sticky top-0 z-30 shadow-md text-stone-100">
      
      {/* Top Main Brand Row */}
      <div className="px-4 lg:px-6 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-stone-900">
        
        {/* Market Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-900 text-white flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)] border border-emerald-500/40">
            <Store className="w-5 h-5 text-emerald-100" />
          </div>
          <div>
            <h1 className="font-black text-2xl text-white tracking-wider font-sans">
              pedros
            </h1>
          </div>
        </div>

        {/* Quick Top Live Stats: چی ماوە vs چی نەماوە */}
        <div className="hidden md:flex items-center gap-4 bg-stone-900/90 px-3.5 py-1.5 rounded-xl border border-emerald-950/80 text-xs shadow-inner">
          <div>
            <span className="text-stone-400 block text-[10px]">چی ماوە (عەمبار):</span>
            <span className="font-black text-emerald-400">{formatNumber(totalStock)} دانە</span>
          </div>
          <div className="h-6 w-px bg-stone-800"></div>
          <div>
            <span className="text-stone-400 block text-[10px]">چی نەماوە (سیفر):</span>
            <span className={`font-black ${outOfStockCount > 0 ? 'text-rose-400' : 'text-stone-400'}`}>
              {outOfStockCount} کاڵا
            </span>
          </div>
          <div className="h-6 w-px bg-stone-800"></div>
          <div>
            <span className="text-stone-400 block text-[10px]">کۆی فرۆشراو:</span>
            <span className="font-black text-cyan-400">{formatNumber(totalSold)} دانە</span>
          </div>
          <div className="h-6 w-px bg-stone-800"></div>
          <div>
            <span className="text-stone-400 block text-[10px]">کۆی داهات:</span>
            <span className="font-black text-white">{formatPrice(totalRevenue, currency)}</span>
          </div>
        </div>

        {/* Currency & Actions */}
        <div className="flex items-center gap-2">
          {/* Currency toggle */}
          <div className="flex items-center bg-stone-900 p-0.5 rounded-xl border border-stone-800 text-xs font-bold shadow-inner">
            <button
              onClick={() => setCurrency('IQD')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                currency === 'IQD'
                  ? 'bg-emerald-600 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              دینار (د.ع)
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                currency === 'USD'
                  ? 'bg-emerald-600 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              دۆلار ($)
            </button>
          </div>

          {/* Download ZIP and Host Guide */}
          <a
            href="/pedros_pos_project.zip"
            download="pedros_pos_project.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-[0_0_12px_rgba(16,185,129,0.3)] transition-all border border-emerald-400/30"
            title="داگرتنی هەموو کۆد و فایلی پڕۆژەکە وەک ZIP"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">داگرتنی ZIP</span>
          </a>

          <button
            onClick={() => setShowExportModal(true)}
            className="p-1.5 px-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 hover:text-emerald-400 border border-stone-800 text-xs font-bold transition-all flex items-center gap-1.5"
            title="ڕێنمایی هۆستکردن و فرۆشتنی پڕۆژە"
          >
            <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">ڕێنمایی هۆست</span>
          </button>

          {/* Reset sample data */}
          <button
            onClick={() => {
              if (confirm('ئایا دڵنیایت لە گەڕاندنەوەی زانیارییە سەرەتاییە نموونەییەکان؟')) {
                onResetSampleData();
              }
            }}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-200 hover:bg-stone-900 border border-transparent hover:border-stone-800 transition-colors"
            title="گەڕاندنەوەی داتای سەرەتایی نموونەیی"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Tabs Navigation Bar (Dark Green & Black Luxury Aesthetics) */}
      <div className="px-4 lg:px-6 flex items-center gap-1.5 overflow-x-auto bg-stone-950/90 border-t border-stone-900">
        
        {/* POS Cashier */}
        <button
          onClick={() => setActiveTab('pos')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'pos'
              ? 'border-emerald-500 text-emerald-400 bg-stone-900/80 shadow-[0_4px_12px_rgba(16,185,129,0.15)]'
              : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/40'
          }`}
        >
          <ShoppingCart className="w-4 h-4" />
          <span>کاشێر و فرۆشتن (POS)</span>
        </button>

        {/* Dedicated Item Entry Section: "داخلکردنی ئەشیا" */}
        <button
          onClick={() => setActiveTab('entry')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'entry'
              ? 'border-emerald-500 text-emerald-400 bg-stone-900/80 shadow-[0_4px_12px_rgba(16,185,129,0.15)]'
              : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/40'
          }`}
        >
          <PackagePlus className="w-4 h-4 text-emerald-400" />
          <span>داخلکردنی ئەشیا و بارنامە</span>
          {outOfStockCount > 0 && (
            <span className="bg-rose-950 border border-rose-600/70 text-rose-300 text-[10px] font-black px-1.5 py-0.5 rounded-full" title="کاڵای نەماو">
              {outOfStockCount} نەماوە
            </span>
          )}
        </button>

        {/* Inventory & Stock: چی ماوە چی نەماوە */}
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'inventory'
              ? 'border-emerald-500 text-emerald-400 bg-stone-900/80 shadow-[0_4px_12px_rgba(16,185,129,0.15)]'
              : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/40'
          }`}
        >
          <Boxes className="w-4 h-4 text-emerald-400" />
          <span>کۆگا و کاڵاکان (ماوە و فرۆشراو)</span>
          <span className="bg-stone-800 text-stone-300 border border-stone-700 text-[11px] px-1.5 py-0.5 rounded-full">
            {products.length}
          </span>
        </button>

        {/* Sales Reports */}
        <button
          onClick={() => setActiveTab('sales')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'sales'
              ? 'border-emerald-500 text-emerald-400 bg-stone-900/80 shadow-[0_4px_12px_rgba(16,185,129,0.15)]'
              : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/40'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span>ڕاپۆرتی فرۆشراوەکان و قازانج</span>
          {sales.length > 0 && (
            <span className="bg-emerald-950 border border-emerald-700/60 text-emerald-300 text-[11px] px-1.5 py-0.5 rounded-full">
              {sales.length}
            </span>
          )}
        </button>

        {/* Barcode & Label Center */}
        <button
          onClick={() => setActiveTab('barcodes')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
            activeTab === 'barcodes'
              ? 'border-emerald-500 text-emerald-400 bg-stone-900/80 shadow-[0_4px_12px_rgba(16,185,129,0.15)]'
              : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/40'
          }`}
        >
          <Barcode className="w-4 h-4 text-emerald-400" />
          <span>بارکۆد ساز و چاپکردنی لەزگە</span>
        </button>

      </div>

      {/* Guide Modal: How to host, sell or run locally */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-stone-100">
            <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <FileArchive className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">ڕێنمایی داگرتن، هۆستکردن و فرۆشتنی پڕۆژەی pedros</h3>
                  <p className="text-xs text-stone-400">فایلی ZIP ئامادەکراوە و دەتوانیت ڕاستەوخۆ داونلۆدی بکەیت</p>
                </div>
              </div>
              <button
                onClick={() => setShowExportModal(false)}
                className="p-2 rounded-xl text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Download Banner */}
            <div className="bg-gradient-to-br from-emerald-950/80 to-stone-900 border border-emerald-500/40 rounded-xl p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="font-bold text-emerald-300 block text-sm">فایلی تەواوی پڕۆژەکە (Source Code ZIP)</span>
                <span className="text-xs text-stone-400">هەموو کۆدەکان، وێنەکان، و ڕێنمایی کارپێکردن بە قەبارەی ٤٩ کەیبی</span>
              </div>
              <a
                href="/pedros_pos_project.zip"
                download="pedros_pos_project.zip"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-stone-950 font-black text-sm flex items-center gap-2 shadow-lg transition-all shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>داگرتنی ZIP ئێستا</span>
              </a>
            </div>

            <div className="space-y-4 text-xs leading-relaxed text-stone-300">
              {/* Option 1: Local */}
              <div className="bg-stone-950/60 border border-stone-800 rounded-xl p-4">
                <div className="flex items-center gap-2 text-emerald-400 font-bold mb-2 text-sm">
                  <Laptop className="w-4 h-4" />
                  <span>١. کارپێکردن لەسەر کۆمپیوتەری کڕیار یان مارکێت (Localhost)</span>
                </div>
                <p className="mb-2 text-stone-400">
                  فایلە زیپەکە بکەرەوە و لە ناو فۆڵدەرەکە لە تێرمیناڵ ئەم دوو فەرمانە لێبدە (پێویستی بە Node.js هەیە):
                </p>
                <div className="bg-stone-900 border border-stone-800 p-2.5 rounded-lg font-mono text-[11px] text-emerald-300 space-y-1" dir="ltr">
                  <div>npm install</div>
                  <div>npm run dev</div>
                </div>
                <p className="mt-2 text-stone-400">
                  پاشان لە کرۆم دەکرێتەوە لە <span className="text-cyan-400 font-mono">http://localhost:3000</span>
                </p>
              </div>

              {/* Option 2: Host on Vercel / Netlify */}
              <div className="bg-stone-950/60 border border-stone-800 rounded-xl p-4">
                <div className="flex items-center gap-2 text-teal-400 font-bold mb-2 text-sm">
                  <Globe className="w-4 h-4" />
                  <span>٢. هۆستکردن لەسەر ئینتەرنێت بۆ ئەوەی لە هەموو شوێنێک بەردەست بێت</span>
                </div>
                <ul className="list-disc list-inside space-y-1.5 text-stone-400">
                  <li>
                    <strong className="text-stone-200">لە Vercel:</strong> فۆڵدەرەکە ببە سەر هەژماری Vercel.com یان GitHub، ڕاستەوخۆ لینکێکی بێبەرامبەرت پێدەدات (وەک pedros.vercel.app).
                  </li>
                  <li>
                    <strong className="text-stone-200">لە Netlify:</strong> لە کۆمپیوتەرەکەت فەرمانی <span className="text-cyan-400 font-mono">npm run build</span> لێبدە، پاشان فۆڵدەری <span className="font-mono text-emerald-400">dist</span> ڕابکێشە بۆ ناو Netlify.com.
                  </li>
                </ul>
              </div>

              {/* Option 3: Turn into app */}
              <div className="bg-stone-950/60 border border-stone-800 rounded-xl p-4">
                <div className="flex items-center gap-2 text-cyan-400 font-bold mb-2 text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>٣. چۆن بیکەیتە ئەپی وێندۆز یان مۆبایل؟</span>
                </div>
                <p className="text-stone-400">
                  لە براوسەری Chrome یا Edge دەتوانیت لە بەشی سەرەوە سێ خاڵەکە دابگریت و کلیک لەسەر <span className="text-stone-200 font-bold">Install pedros as app</span> بکەیت تا دەستبەجێ وەک بەرنامەیەکی فەرمی بچێتە ناو لیستی پرۆگرامەکانی کۆمپیوتەر بە بێ هیچ پێداویستییەک.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-stone-800 flex justify-end">
              <button
                onClick={() => setShowExportModal(false)}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs transition-colors"
              >
                داخستن
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
