import React, { useState } from 'react';
import { 
  X, 
  Monitor, 
  Smartphone, 
  Share2, 
  Copy, 
  Check, 
  Download, 
  ShieldCheck,
  FileArchive,
  Usb,
  FolderDown,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { playSuccessChime } from '../utils/audio';

interface PublishSellGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PublishSellGuideModal: React.FC<PublishSellGuideModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [copiedZipLink, setCopiedZipLink] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipDownloaded, setZipDownloaded] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'pc' | 'mobile' | 'zip'>('pc');

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const originUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const zipDownloadUrl = `${originUrl}/pedros_pos_project.zip`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(currentUrl)}&color=ffffff&bgcolor=1c1917`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleCopyZipLink = () => {
    navigator.clipboard.writeText(zipDownloadUrl);
    setCopiedZipLink(true);
    setTimeout(() => setCopiedZipLink(false), 2500);
  };

  const handleDownloadZip = () => {
    try {
      playSuccessChime();
    } catch {
      // ignore
    }
    setIsDownloadingZip(true);
    
    // Trigger download
    const link = document.createElement('a');
    link.href = '/pedros_pos_project.zip';
    link.setAttribute('download', 'pedros_pos_project.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setIsDownloadingZip(false);
      setZipDownloaded(true);
      setTimeout(() => setZipDownloaded(false), 4000);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div 
        className="w-full max-w-3xl bg-stone-950 border border-red-900/60 rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.25)] flex flex-col max-h-[92vh] overflow-hidden text-stone-100 animate-in fade-in zoom-in duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-stone-950 via-red-950/40 to-stone-950 border-b border-red-900/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/50 flex items-center justify-center text-red-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                Connect to Device (PC & مۆبایل)
              </h2>
              <p className="text-xs text-stone-400">
                بردن و دانانی پڕۆژە لەسەر کۆمپیوتەری کاشێر، مۆبایل، یان دابەزاندنی وەک فایلی ZIP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 border border-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live URL & Instant Download Quick Bar */}
        <div className="px-5 py-3 bg-stone-900/80 border-b border-stone-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="text-xs text-stone-400 whitespace-nowrap font-medium">بەستەری بەرنامەکە:</span>
            <code className="text-xs bg-stone-950 px-2.5 py-1.5 rounded-lg border border-stone-800 text-red-300 font-mono truncate max-w-xs sm:max-w-sm select-all">
              {currentUrl}
            </code>
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-xs font-semibold text-stone-200 transition-all border border-stone-700 active:scale-95 shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'کۆپیکرا!' : 'کۆپیکردنی لینک'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Quick ZIP Download Button */}
            <button
              onClick={handleDownloadZip}
              disabled={isDownloadingZip}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs border transition-all active:scale-95 ${
                zipDownloaded
                  ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300'
                  : 'bg-stone-800 hover:bg-stone-700 border-amber-500/50 hover:border-amber-400 text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
              }`}
              title="دابەزاندنی فایلی ZIPی تەواوی پڕۆژە"
            >
              {zipDownloaded ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 animate-bounce" />
                  <span>داگیرا! (ZIP)</span>
                </>
              ) : (
                <>
                  <FileArchive className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isDownloadingZip ? 'داگرتن...' : 'فایلی ZIP داگرە'}</span>
                </>
              )}
            </button>

            {/* Quick Install Action if available */}
            {isInstallable && (
              <button
                onClick={install}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs shadow-[0_0_15px_rgba(239,68,68,0.4)] border border-red-500 transition-all active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>دابەزاندنی ئەپ (Install)</span>
              </button>
            )}
          </div>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex border-b border-stone-800 bg-stone-950 px-5 pt-2 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('pc')}
            className={`flex items-center gap-2 py-2.5 px-4 border-b-2 font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'pc'
                ? 'border-red-500 text-red-400 bg-red-950/20'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>١. دانان لەسەر کۆمپیوتەر (PC)</span>
          </button>
          <button
            onClick={() => setActiveSubTab('mobile')}
            className={`flex items-center gap-2 py-2.5 px-4 border-b-2 font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'mobile'
                ? 'border-red-500 text-red-400 bg-red-950/20'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>٢. دانان لەسەر مۆبایل و تابلێت</span>
          </button>
          <button
            onClick={() => setActiveSubTab('zip')}
            className={`flex items-center gap-2 py-2.5 px-4 border-b-2 font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'zip'
                ? 'border-amber-500 text-amber-300 bg-amber-950/20'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <FileArchive className="w-4 h-4 text-amber-400" />
            <span>٣. فایلی ZIP پڕۆژە (داگرتنی تەواو)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-sm">
          
          {/* TAB 1: PC Installation */}
          {activeSubTab === 'pc' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-stone-900 border border-red-900/40">
                <h3 className="font-bold text-base text-white flex items-center gap-2 mb-2">
                  <Monitor className="w-5 h-5 text-red-400" />
                  چۆن دەچێتە ناو کۆمپیوتەری کاشێر لە سوپەرمارکێت؟
                </h3>
                <p className="text-stone-300 text-xs leading-relaxed">
                  ئەم بەرنامەیە لەسەر ستانداردەکانی <strong className="text-red-400">PWA (Progressive Web App)</strong> دروستکراوە. کاتێک بەستەرەکە لەسەر کۆمپیوتەری سوپەرمارکێت دەکەیتەوە، پێویست ناکات وەک وێبسایت بەکاری بهێنن؛ ڕاستەوخۆ دەبێتە بەرنامەی فەرمی ویندۆز لەسەر Desktop!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-stone-900/60 border border-stone-800 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-bold flex items-center justify-center text-xs">
                    ١
                  </div>
                  <h4 className="font-bold text-white text-xs">لە وێبگەڕی کۆمپیوتەر بیکەرەوە</h4>
                  <p className="text-stone-400 text-xs leading-relaxed">
                    لە کۆمپیوتەری مارکێت لە Google Chrome یان Microsoft Edge بەستەری پڕۆژەکەت بکەرەوە.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-stone-900/60 border border-stone-800 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-bold flex items-center justify-center text-xs">
                    ٢
                  </div>
                  <h4 className="font-bold text-white text-xs">کلیک لە «Install» بکە</h4>
                  <p className="text-stone-400 text-xs leading-relaxed">
                    لە سەرەوەی گەڕانچیدا لە تەنیشت بەستەرەکە یان لە دوگمەی ناوخۆی بەرنامەکە کلیک لە <strong>Install App</strong> بکە.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-stone-900/60 border border-stone-800 space-y-2">
                  <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-bold flex items-center justify-center text-xs">
                    ٣
                  </div>
                  <h4 className="font-bold text-white text-xs">ئایکۆن لەسەر Desktop دروست دەبێت</h4>
                  <p className="text-stone-400 text-xs leading-relaxed">
                    بەرنامەکە ڕاستەوخۆ دەکەوێتە سەر شاشەی کۆمپیوتەر (Desktop) و بەبێ گەڕانچی دەکرێتەوە و لە ئۆفلاینیش کار دەکات.
                  </p>
                </div>
              </div>

              {/* Offline & ZIP Transfer Option inside PC tab */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/30 via-stone-900 to-stone-900 border border-amber-600/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <Usb className="w-4 h-4" />
                    <span>بردن بە فلاش مێمۆری (USB Flash) بە فایلی ZIP:</span>
                  </div>
                  <p className="text-stone-300 text-xs leading-relaxed">
                    ئەگەر کۆمپیوتەری مارکێت ئینتەرنێتی نەبوو، دەتوانیت تەواوی فایلەکانی پڕۆژەکە بە ZIP داببەزێنیت و بیخەیتە سەر فلاش مێمۆری.
                  </p>
                </div>
                <button
                  onClick={handleDownloadZip}
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-black text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(245,158,11,0.3)] transition-all active:scale-95 shrink-0"
                >
                  <FileArchive className="w-4 h-4" />
                  <span>داگرتنی فایلی ZIP</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-stone-900/40 border border-stone-800 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-stone-300 space-y-1">
                  <strong className="text-white block">پەیوەستکردنی بارکۆد خوێنەر و پرنتەر لەسەر PC:</strong>
                  <span>
                    هەموو بارکۆد خوێنەرێکی USB و تەڕازووی بارکۆددار بە شێوەی خۆکار ڕاستەوخۆ لەسەر شاشەی POS کار دەکەن. لەگەڵ پرنتەری وەسڵی 80mm تەنیا کلیک لە "چاپکردنی وەسڵ" دەکرێت.
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Mobile Installation */}
          {activeSubTab === 'mobile' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-stone-900 border border-red-900/40 flex flex-col sm:flex-row items-center gap-5">
                <div className="p-2.5 rounded-xl bg-stone-950 border border-stone-800 shrink-0">
                  <img 
                    src={qrCodeUrl} 
                    alt="Mobile QR Code" 
                    className="w-36 h-36 rounded-lg object-contain"
                  />
                </div>
                <div className="space-y-2 text-center sm:text-right">
                  <span className="text-[11px] bg-red-950 border border-red-700/50 text-red-300 px-2 py-0.5 rounded-full inline-block font-bold">
                    سکانکردنی خێرا بە مۆبایل
                  </span>
                  <h3 className="font-bold text-base text-white">
                    کامێرای مۆبایلەکەت لەسەر ئەم کۆدە ڕابگرە
                  </h3>
                  <p className="text-stone-300 text-xs leading-relaxed">
                    کامێرای هەر مۆبایلێک یان تابلێتێک (ئەندرۆید یان ئایفۆن) بەکاربهێنە بۆ ئەوەی ڕاستەوخۆ بەستەرەکە بکەیتەوە لەسەر مۆبایل و دایبەزێنیتە سەر شاشەی مۆبایل.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-stone-900/70 border border-stone-800 space-y-2">
                  <h4 className="font-bold text-white text-xs flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    مۆبایلی ئەندرۆید (Samsung / Xiaomi / Huawei):
                  </h4>
                  <ul className="text-xs text-stone-300 space-y-1 list-disc list-inside">
                    <li>بەستەرەکە لە Google Chrome بکەرەوە.</li>
                    <li>دوگمەی خوارەوە لەسەر شاشە دەنووسێت <strong>«Install pedros POS»</strong>.</li>
                    <li>یان لە ٣ خاڵەکەی سەرەوە کلیک لە <strong>«Add to Home screen»</strong> بکە.</li>
                    <li>دەبێتە ئەپڵیکەیشنێکی سەربەخۆ لەناو مۆبایلدا.</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-stone-900/70 border border-stone-800 space-y-2">
                  <h4 className="font-bold text-white text-xs flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                    مۆبایلی ئایفۆن و ئایپاد (Apple iOS):
                  </h4>
                  <ul className="text-xs text-stone-300 space-y-1 list-disc list-inside">
                    <li>بەستەرەکە لە وێبگەڕی <strong>Safari</strong> بکەرەوە.</li>
                    <li>لە خوارەوە پەنجە بنێ بە نیشانەی هاوبەشکردن (<strong>Share Icon</strong>).</li>
                    <li>بڕۆ خوارەوە و کلیک لە <strong>«Add to Home Screen»</strong> بکە.</li>
                    <li>بەرنامەکە لەگەڵ ئایکۆنی ڕەش و سوور دەکەوێتە سەر شاشەی ئایفۆن.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Dedicated ZIP File Creator & Downloader */}
          {activeSubTab === 'zip' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-gradient-to-br from-stone-900 via-stone-900 to-amber-950/30 border border-amber-500/40 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
                
                <div className="flex flex-col md:flex-row items-center justify-between gap-5 relative z-10">
                  <div className="space-y-2 text-center md:text-right">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>فایلی ZIP پڕۆژە بە تەواوی ئامادەیە</span>
                    </div>
                    <h3 className="text-lg font-black text-white">
                      داگرتنی تەواوی پڕۆژەکە (pedros_pos_project.zip)
                    </h3>
                    <p className="text-stone-300 text-xs leading-relaxed max-w-xl">
                      ئەم فایلی ZIPیە هەموو کۆدەکانی سەرچاوەی سیستەمەکە، لاپەڕەکان، ئایکۆنەکان و داتاکانی تێدایە. دەتوانیت بە ئاسانی بیخەیتە سەر فلاش مێمۆری، بینێریت بۆ کڕیاری مارکێت لە ڕێگەی تێلیگرام یان ئیمەیڵ، یان وەک کۆپیەکی پارێزراو (Backup) لەسەر کۆمپیوتەری خۆت هەڵیبگریت.
                    </p>
                  </div>

                  <div className="flex flex-col items-center gap-2.5 w-full md:w-auto shrink-0">
                    <button
                      onClick={handleDownloadZip}
                      disabled={isDownloadingZip}
                      className={`w-full md:w-auto px-6 py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2.5 transition-all shadow-[0_0_25px_rgba(245,158,11,0.35)] active:scale-95 ${
                        zipDownloaded 
                          ? 'bg-emerald-600 text-white border border-emerald-400' 
                          : 'bg-gradient-to-r from-amber-500 via-amber-600 to-red-600 hover:from-amber-400 hover:to-red-500 text-stone-950 font-black'
                      }`}
                    >
                      {zipDownloaded ? (
                        <>
                          <CheckCircle2 className="w-5 h-5 text-white animate-bounce" />
                          <span>داگیرا! سەرکەوتووانە دابەزی</span>
                        </>
                      ) : (
                        <>
                          <FolderDown className="w-5 h-5" />
                          <span>{isDownloadingZip ? 'دروستکردن و داگرتن...' : 'دابەزاندنی ڕاستەوخۆ (ZIP)'}</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleCopyZipLink}
                      className="text-xs text-stone-400 hover:text-stone-200 flex items-center gap-1.5 transition-colors py-1"
                    >
                      {copiedZipLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedZipLink ? 'لینکی فایلی ZIP کۆپیکرا!' : 'کۆپیکردنی لینکی داگرتن'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Information & Specifications */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 space-y-1">
                  <span className="text-[11px] text-stone-400">ناوی فایل:</span>
                  <div className="font-mono text-xs text-amber-300 font-bold truncate">
                    pedros_pos_project.zip
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 space-y-1">
                  <span className="text-[11px] text-stone-400">قەبارەی پەستێنراو:</span>
                  <div className="text-xs text-white font-bold">
                    نزیکەی ٢١٨ کیلۆبایت (فایلەکان بە تەواوی ئامادەن)
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 space-y-1 sm:col-span-2 md:col-span-1">
                  <span className="text-[11px] text-stone-400">ناوەڕۆکی فایل:</span>
                  <div className="text-xs text-emerald-400 font-bold">
                    React + TypeScript + PWA + بارکۆد
                  </div>
                </div>
              </div>

              {/* How to use the ZIP file step by step */}
              <div className="p-4 rounded-xl bg-stone-900/40 border border-stone-800 space-y-3">
                <h4 className="font-bold text-white text-xs flex items-center gap-2">
                  <Usb className="w-4 h-4 text-amber-400" />
                  <span>چۆن فایلی ZIP بەکاردەهێنیت بۆ بردنە سەر کۆمپیوتەری سوپەرمارکێت؟</span>
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800/80 space-y-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-stone-950 font-black text-[11px] flex items-center justify-center">١</span>
                    <strong className="text-white text-xs block">داگرتنی فایلەکە</strong>
                    <p className="text-stone-400 text-xs leading-relaxed">
                      کلیک لە دوگمەی سەرەوە بکە و فایلەکە لە کۆمپیوتەرەکەت دابەزێنە.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800/80 space-y-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-stone-950 font-black text-[11px] flex items-center justify-center">٢</span>
                    <strong className="text-white text-xs block">خستنەسەر فلاش (USB)</strong>
                    <p className="text-stone-400 text-xs leading-relaxed">
                      فایلی ZIPەکە کۆپی بکە بۆ سەر فلاش مێمۆری و بیبە بۆ سوپەرمارکێتەکە.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800/80 space-y-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-stone-950 font-black text-[11px] flex items-center justify-center">٣</span>
                    <strong className="text-white text-xs block">دەرهێنان (Extract)</strong>
                    <p className="text-stone-400 text-xs leading-relaxed">
                      لە ویندۆزی کۆمپیوتەری مارکێت کلیکی ڕاست لەسەر فایلەکە بکە و Extract All هەڵبژێرە.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-stone-950 border-t border-stone-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500">
              سیستەمی بازرگانی pedros POS
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-stone-900 text-stone-400 border border-stone-800">
              ZIP Package Ready
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition-colors"
          >
            داخستن
          </button>
        </div>
      </div>
    </div>
  );
};
